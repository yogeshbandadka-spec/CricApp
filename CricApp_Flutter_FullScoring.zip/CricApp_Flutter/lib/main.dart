import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'screens/auth_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Firebase options are read from the native Android configuration
  // (google-services.json) in this starter project.
  await Firebase.initializeApp();

  runApp(const CricApp());
}

class CricApp extends StatelessWidget {
  const CricApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CricApp',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}
