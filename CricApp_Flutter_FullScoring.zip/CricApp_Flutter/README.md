# CricApp Flutter — Live Cricket Scoring

Firebase-connected Flutter source project for an admin scoring phone and public live-score viewer phones.

## Features
- Public live score view (no login required)
- Admin Email/Password login using Firebase Authentication
- Admin logout
- 0, 1, 2, 3, 4, 6 scoring
- Wide, No-ball, Bye, Leg-bye
- Wicket
- Automatic strike change on odd legal runs
- Automatic end-of-over strike change
- Overs / legal-ball tracking
- Batter runs, balls, 4s, 6s and strike rate
- Extras summary
- Recent ball-by-ball chips
- Undo
- Batter name editing
- Start 2nd innings with automatic target = first innings score + 1
- Chase-won / all-out match status
- Firebase Realtime Database live sync at `matches/demo`

## Firebase setup already completed
- Firebase project: `cricapp-22087`
- Android package: `com.cricapp.live`
- Email/Password provider enabled
- Admin user created in Firebase Authentication
- `android/app/google-services.json` included

## Database rules
`firebase_database.rules.json` is included. It is designed so everyone can read the live score, while only authenticated admins can write scores.

Deploy those rules from Firebase Console > Realtime Database > Rules, or with Firebase CLI.

## Build
A Flutter SDK/build environment is required to generate an APK.

```bash
flutter pub get
flutter run
```

If generated platform files are missing in an online Flutter environment, run:

```bash
flutter create .
```

Never commit or publish the Admin password.
