import 'package:firebase_database/firebase_database.dart';

import '../models/match_state.dart';

class FirebaseScoreService {
  final DatabaseReference _matchRef =
      FirebaseDatabase.instance.ref('matches/demo');

  Stream<MatchState> watchMatch() => _matchRef.onValue.map((event) {
        final value = event.snapshot.value;
        return value is Map ? MatchState.fromMap(value) : _initial();
      });

  Future<void> saveMatch(MatchState state) => _matchRef.set(state.toMap());

  MatchState _initial() => MatchState(
        batters: const {
          'Batter 1': BatterStat(name: 'Batter 1'),
          'Batter 2': BatterStat(name: 'Batter 2'),
        },
      );

  Future<MatchState> _get() async {
    final snap = await _matchRef.get();
    if (snap.value is Map) return MatchState.fromMap(snap.value as Map);
    return _initial();
  }

  Future<void> resetMatch() => saveMatch(_initial());

  Future<void> setBatterNames(String striker, String nonStriker) async {
    final current = await _get();
    final batters = Map<String, BatterStat>.from(current.batters);
    batters.putIfAbsent(striker, () => BatterStat(name: striker));
    batters.putIfAbsent(nonStriker, () => BatterStat(name: nonStriker));
    await saveMatch(current.copyWith(
      striker: striker,
      nonStriker: nonStriker,
      batters: batters,
    ));
  }

  Future<void> addRuns(int runs) async {
    if (![0, 1, 2, 3, 4, 6].contains(runs)) return;
    await _apply(label: '$runs', teamRuns: runs, batterRuns: runs);
  }

  Future<void> addWide() => _apply(
        label: 'WD',
        teamRuns: 1,
        batterRuns: 0,
        legal: false,
        extraKey: 'wides',
      );

  Future<void> addNoBall() => _apply(
        label: 'NB',
        teamRuns: 1,
        batterRuns: 0,
        legal: false,
        extraKey: 'noBalls',
      );

  Future<void> addBye() => _apply(
        label: 'B',
        teamRuns: 1,
        batterRuns: 0,
        extraKey: 'byes',
      );

  Future<void> addLegBye() => _apply(
        label: 'LB',
        teamRuns: 1,
        batterRuns: 0,
        extraKey: 'legByes',
      );

  Future<void> addWicket() async {
    final current = await _get();
    if (current.matchEnded) return;
    final snapshot = current.toMap(includeHistory: false);
    final history = [...current.history, snapshot];
    final batters = Map<String, BatterStat>.from(current.batters);
    final old = batters[current.striker] ?? BatterStat(name: current.striker);
    batters[current.striker] = old.copyWith(out: true, balls: old.balls + 1);
    final nextNumber = batters.length + 1;
    final newName = 'Batter $nextNumber';
    batters[newName] = BatterStat(name: newName);

    var state = current.copyWith(
      runs: current.runs,
      wickets: current.wickets + 1,
      legalBalls: current.legalBalls + 1,
      totalBalls: current.totalBalls + 1,
      striker: newName,
      batters: batters,
      history: history,
      recentBalls: _recent(current, 'W'),
    );
    state = _finishIfNeeded(state);
    await saveMatch(state);
  }

  Future<void> undo() async {
    final current = await _get();
    if (current.history.isEmpty) return;
    final previousMap = current.history.last;
    final remaining = current.history.sublist(0, current.history.length - 1);
    final previous = MatchState.fromMap(previousMap).copyWith(history: remaining);
    await saveMatch(previous);
  }

  Future<void> startSecondInnings() async {
    final current = await _get();
    final target = current.runs + 1;
    final state = MatchState(
      target: target,
      innings: 2,
      striker: 'Batter 1',
      nonStriker: 'Batter 2',
      batters: const {
        'Batter 1': BatterStat(name: 'Batter 1'),
        'Batter 2': BatterStat(name: 'Batter 2'),
      },
      status: 'LIVE',
    );
    await saveMatch(state);
  }

  Future<void> _apply({
    required String label,
    required int teamRuns,
    required int batterRuns,
    bool legal = true,
    String? extraKey,
  }) async {
    final current = await _get();
    if (current.matchEnded) return;
    final snapshot = current.toMap(includeHistory: false);
    final history = [...current.history, snapshot];
    final batters = Map<String, BatterStat>.from(current.batters);
    final batter = batters[current.striker] ?? BatterStat(name: current.striker);
    batters[current.striker] = batter.copyWith(
      runs: batter.runs + batterRuns,
      balls: batter.balls + (legal ? 1 : 0),
      fours: batter.fours + (batterRuns == 4 ? 1 : 0),
      sixes: batter.sixes + (batterRuns == 6 ? 1 : 0),
    );
    final extras = Map<String, int>.from(current.extras);
    if (extraKey != null) extras[extraKey] = (extras[extraKey] ?? 0) + 1;

    var striker = current.striker;
    var nonStriker = current.nonStriker;
    if (legal && teamRuns.isOdd) {
      final temp = striker;
      striker = nonStriker;
      nonStriker = temp;
    }

    final legalBalls = current.legalBalls + (legal ? 1 : 0);
    if (legal && legalBalls % 6 == 0) {
      final temp = striker;
      striker = nonStriker;
      nonStriker = temp;
    }

    var state = current.copyWith(
      runs: current.runs + teamRuns,
      legalBalls: legalBalls,
      totalBalls: current.totalBalls + 1,
      striker: striker,
      nonStriker: nonStriker,
      batters: batters,
      extras: extras,
      recentBalls: _recent(current, label),
      history: history,
    );
    state = _finishIfNeeded(state);
    await saveMatch(state);
  }

  MatchState _finishIfNeeded(MatchState state) {
    if (state.innings == 2 && state.target > 0 && state.runs >= state.target) {
      return state.copyWith(matchEnded: true, status: 'CHASE WON');
    }
    if (state.wickets >= 10) {
      return state.copyWith(matchEnded: true, status: 'ALL OUT');
    }
    return state;
  }

  List<BallEvent> _recent(MatchState current, String label) {
    final list = [...current.recentBalls, BallEvent(
      label: label,
      teamRuns: 0,
      batterRuns: 0,
      legalBalls: current.legalBalls,
    )];
    if (list.length > 12) list.removeRange(0, list.length - 12);
    return list;
  }
}
