import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../models/match_state.dart';
import '../services/firebase_score_service.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final FirebaseScoreService _service = FirebaseScoreService();
  bool get isAdmin => FirebaseAuth.instance.currentUser != null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CricApp Live Score'),
        actions: [
          if (isAdmin)
            IconButton(
              tooltip: 'Logout',
              onPressed: () => FirebaseAuth.instance.signOut(),
              icon: const Icon(Icons.logout),
            )
          else
            IconButton(
              tooltip: 'Admin Login',
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const LoginScreen())),
              icon: const Icon(Icons.admin_panel_settings),
            ),
        ],
      ),
      body: StreamBuilder<MatchState>(
        stream: _service.watchMatch(),
        builder: (context, snapshot) {
          final state = snapshot.data ?? const MatchState();
          return RefreshIndicator(
            onRefresh: () async {},
            child: ListView(
              padding: const EdgeInsets.all(14),
              children: [
                _scoreCard(state),
                const SizedBox(height: 12),
                _battersCard(state),
                const SizedBox(height: 12),
                _extrasCard(state),
                const SizedBox(height: 12),
                _ballRow(state),
                if (isAdmin) ...[
                  const SizedBox(height: 14),
                  _adminPanel(state),
                ],
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _scoreCard(MatchState state) => Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('INNINGS ${state.innings}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  Chip(label: Text(state.status)),
                ],
              ),
              Text('${state.runs}/${state.wickets}',
                  style: Theme.of(context).textTheme.displayMedium),
              Text('Overs ${state.legalBalls ~/ 6}.${state.legalBalls % 6}'),
              if (state.innings == 2 && state.target > 0)
                Text('Target: ${state.target}  •  Need: ${((state.target - state.runs).clamp(0, state.target))}',
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              if (state.matchEnded)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(state.status,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
            ],
          ),
        ),
      );

  Widget _battersCard(MatchState state) {
    final names = <String>{state.striker, state.nonStriker};
    final stats = names
        .map((n) => state.batters[n] ?? BatterStat(name: n))
        .toList();
    return Card(
      child: Column(
        children: [
          const ListTile(title: Text('Batters')),
          ...stats.map((b) => ListTile(
                leading: Icon(b.name == state.striker
                    ? Icons.sports_cricket
                    : Icons.person_outline),
                title: Text('${b.name}${b.name == state.striker ? '  *' : ''}'),
                subtitle: Text('${b.runs} (${b.balls})  •  4s ${b.fours}  •  6s ${b.sixes}'),
                trailing: b.balls == 0
                    ? const Text('0.00')
                    : Text((b.runs * 100 / b.balls).toStringAsFixed(2)),
              )),
        ],
      ),
    );
  }

  Widget _extrasCard(MatchState state) {
    final total = state.extras.values.fold<int>(0, (a, b) => a + b);
    return Card(
      child: ListTile(
        title: const Text('Extras'),
        subtitle: Text('WD ${state.extras['wides'] ?? 0}  •  NB ${state.extras['noBalls'] ?? 0}  •  B ${state.extras['byes'] ?? 0}  •  LB ${state.extras['legByes'] ?? 0}'),
        trailing: Text('$total'),
      ),
    );
  }

  Widget _ballRow(MatchState state) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Wrap(
            spacing: 7,
            runSpacing: 7,
            children: state.recentBalls.isEmpty
                ? [const Text('Ball-by-ball will appear here')]
                : state.recentBalls.map((b) => Chip(label: Text(b.label))).toList(),
          ),
        ),
      );

  Widget _adminPanel(MatchState state) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('ADMIN SCORING',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [0, 1, 2, 3, 4, 6]
                    .map((r) => FilledButton(
                          onPressed: state.matchEnded ? null : () => _service.addRuns(r),
                          child: Text('$r'),
                        ))
                    .toList(),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _action('Wide', _service.addWide, Icons.arrow_forward),
                  _action('No-ball', _service.addNoBall, Icons.warning_amber),
                  _action('Bye', _service.addBye, Icons.directions_run),
                  _action('Leg-bye', _service.addLegBye, Icons.directions_run),
                  _action('Wicket', _service.addWicket, Icons.close),
                  _action('Undo', _service.undo, Icons.undo),
                ],
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () => _namesDialog(state),
                icon: const Icon(Icons.edit),
                label: const Text('Batter Names'),
              ),
              OutlinedButton.icon(
                onPressed: () => _service.startSecondInnings(),
                icon: const Icon(Icons.sports_cricket),
                label: const Text('Start 2nd Innings'),
              ),
              TextButton.icon(
                onPressed: () => _confirmReset(),
                icon: const Icon(Icons.restart_alt),
                label: const Text('New Match / Reset'),
              ),
            ],
          ),
        ),
      );

  Widget _action(String text, Future<void> Function() action, IconData icon) =>
      OutlinedButton.icon(
        onPressed: () => action(),
        icon: Icon(icon, size: 18),
        label: Text(text),
      );

  Future<void> _namesDialog(MatchState state) async {
    final striker = TextEditingController(text: state.striker);
    final non = TextEditingController(text: state.nonStriker);
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Batter Names'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: striker, decoration: const InputDecoration(labelText: 'Striker')),
            TextField(controller: non, decoration: const InputDecoration(labelText: 'Non-striker')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final a = striker.text.trim().isEmpty ? 'Batter 1' : striker.text.trim();
              final b = non.text.trim().isEmpty ? 'Batter 2' : non.text.trim();
              await _service.setBatterNames(a, b);
              if (mounted) Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmReset() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Reset match?'),
        content: const Text('Current score will be cleared.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Reset')),
        ],
      ),
    );
    if (ok == true) await _service.resetMatch();
  }
}
