This archive contains the source/project structure needed for CricApp.
A machine with Flutter SDK should run `flutter create .` in this folder (or
use an online Flutter build environment) to regenerate any standard Flutter
generated files not included in this starter archive.
