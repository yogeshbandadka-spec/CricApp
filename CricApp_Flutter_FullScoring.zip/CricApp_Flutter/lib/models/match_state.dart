class BatterStat {
  final String name;
  final int runs;
  final int balls;
  final int fours;
  final int sixes;
  final bool out;

  const BatterStat({
    required this.name,
    this.runs = 0,
    this.balls = 0,
    this.fours = 0,
    this.sixes = 0,
    this.out = false,
  });

  BatterStat copyWith({
    String? name,
    int? runs,
    int? balls,
    int? fours,
    int? sixes,
    bool? out,
  }) => BatterStat(
        name: name ?? this.name,
        runs: runs ?? this.runs,
        balls: balls ?? this.balls,
        fours: fours ?? this.fours,
        sixes: sixes ?? this.sixes,
        out: out ?? this.out,
      );

  Map<String, dynamic> toMap() => {
        'name': name,
        'runs': runs,
        'balls': balls,
        'fours': fours,
        'sixes': sixes,
        'out': out,
      };

  factory BatterStat.fromMap(dynamic value) {
    final map = value is Map ? value : <dynamic, dynamic>{};
    int n(dynamic v) => v is num ? v.toInt() : int.tryParse('$v') ?? 0;
    return BatterStat(
      name: '${map['name'] ?? 'Batter'}',
      runs: n(map['runs']),
      balls: n(map['balls']),
      fours: n(map['fours']),
      sixes: n(map['sixes']),
      out: map['out'] == true,
    );
  }
}

class BallEvent {
  final String label;
  final int teamRuns;
  final int batterRuns;
  final int legalBalls;

  const BallEvent({
    required this.label,
    required this.teamRuns,
    required this.batterRuns,
    required this.legalBalls,
  });

  Map<String, dynamic> toMap() => {
        'label': label,
        'teamRuns': teamRuns,
        'batterRuns': batterRuns,
        'legalBalls': legalBalls,
      };
}

class MatchState {
  final int runs;
  final int wickets;
  final int legalBalls;
  final int totalBalls;
  final int target;
  final int innings;
  final String striker;
  final String nonStriker;
  final Map<String, BatterStat> batters;
  final Map<String, int> extras;
  final List<BallEvent> recentBalls;
  final List<Map<String, dynamic>> history;
  final bool matchEnded;
  final String status;

  const MatchState({
    this.runs = 0,
    this.wickets = 0,
    this.legalBalls = 0,
    this.totalBalls = 0,
    this.target = 0,
    this.innings = 1,
    this.striker = 'Batter 1',
    this.nonStriker = 'Batter 2',
    this.batters = const {},
    this.extras = const {},
    this.recentBalls = const [],
    this.history = const [],
    this.matchEnded = false,
    this.status = 'LIVE',
  });

  MatchState copyWith({
    int? runs,
    int? wickets,
    int? legalBalls,
    int? totalBalls,
    int? target,
    int? innings,
    String? striker,
    String? nonStriker,
    Map<String, BatterStat>? batters,
    Map<String, int>? extras,
    List<BallEvent>? recentBalls,
    List<Map<String, dynamic>>? history,
    bool? matchEnded,
    String? status,
  }) => MatchState(
        runs: runs ?? this.runs,
        wickets: wickets ?? this.wickets,
        legalBalls: legalBalls ?? this.legalBalls,
        totalBalls: totalBalls ?? this.totalBalls,
        target: target ?? this.target,
        innings: innings ?? this.innings,
        striker: striker ?? this.striker,
        nonStriker: nonStriker ?? this.nonStriker,
        batters: batters ?? this.batters,
        extras: extras ?? this.extras,
        recentBalls: recentBalls ?? this.recentBalls,
        history: history ?? this.history,
        matchEnded: matchEnded ?? this.matchEnded,
        status: status ?? this.status,
      );

  Map<String, dynamic> toMap({bool includeHistory = true}) => {
        'runs': runs,
        'wickets': wickets,
        'legalBalls': legalBalls,
        'totalBalls': totalBalls,
        'target': target,
        'innings': innings,
        'striker': striker,
        'nonStriker': nonStriker,
        'batters': batters.map((k, v) => MapEntry(k, v.toMap())),
        'extras': extras,
        'recentBalls': recentBalls.map((e) => e.toMap()).toList(),
        if (includeHistory) 'history': history,
        'matchEnded': matchEnded,
        'status': status,
      };

  factory MatchState.fromMap(Map<dynamic, dynamic> map) {
    int n(dynamic v) => v is num ? v.toInt() : int.tryParse('$v') ?? 0;
    final rawBatters = map['batters'];
    final batters = <String, BatterStat>{};
    if (rawBatters is Map) {
      rawBatters.forEach((key, value) {
        batters['$key'] = BatterStat.fromMap(value);
      });
    }
    final rawExtras = map['extras'];
    final extras = <String, int>{};
    if (rawExtras is Map) {
      rawExtras.forEach((key, value) => extras['$key'] = n(value));
    }
    final recent = <BallEvent>[];
    final rawRecent = map['recentBalls'];
    if (rawRecent is List) {
      for (final item in rawRecent) {
        if (item is Map) {
          recent.add(BallEvent(
            label: '${item['label'] ?? ''}',
            teamRuns: n(item['teamRuns']),
            batterRuns: n(item['batterRuns']),
            legalBalls: n(item['legalBalls']),
          ));
        }
      }
    }
    final history = <Map<String, dynamic>>[];
    final rawHistory = map['history'];
    if (rawHistory is List) {
      for (final item in rawHistory) {
        if (item is Map) history.add(Map<String, dynamic>.from(item));
      }
    }
    return MatchState(
      runs: n(map['runs']),
      wickets: n(map['wickets']),
      legalBalls: n(map['legalBalls']),
      totalBalls: n(map['totalBalls']),
      target: n(map['target']),
      innings: n(map['innings']) == 0 ? 1 : n(map['innings']),
      striker: '${map['striker'] ?? 'Batter 1'}',
      nonStriker: '${map['nonStriker'] ?? 'Batter 2'}',
      batters: batters,
      extras: extras,
      recentBalls: recent,
      history: history,
      matchEnded: map['matchEnded'] == true,
      status: '${map['status'] ?? 'LIVE'}',
    );
  }
}
